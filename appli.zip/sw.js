// Service worker : permet l'utilisation hors connexion.
// Pour publier une mise à jour, augmentez le numéro de version ci-dessous (v28 -> v29).
const CACHE = "doses-ag-v59";
const FICHIERS = ["./", "./index.html", "./manifest.json", "./icon-192.png", "./icon-512.png", "./thumb-1.jpg", "./thumb-2.jpg"];

self.addEventListener("install", event => {
  event.waitUntil(
    caches.open(CACHE)
      .then(cache => cache.addAll(FICHIERS))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", event => {
  event.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", event => {
  if (event.request.method !== "GET") return;
  event.respondWith(
    caches.match(event.request).then(reponse => {
      if (reponse) return reponse;
      return fetch(event.request).then(reseau => {
        const copie = reseau.clone();
        caches.open(CACHE).then(cache => cache.put(event.request, copie));
        return reseau;
      }).catch(() => caches.match("./index.html"));
    })
  );
});
